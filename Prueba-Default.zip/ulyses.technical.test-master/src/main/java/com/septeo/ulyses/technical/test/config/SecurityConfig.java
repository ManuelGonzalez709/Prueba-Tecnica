package com.septeo.ulyses.technical.test.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class SecurityConfig {

    // TODO: implement here your security configuration

}
